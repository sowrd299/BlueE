<?php if (!defined('IN_PHPBB')) exit; ?><div><?php echo (isset($this->_rootref['S_FORM_TOKEN'])) ? $this->_rootref['S_FORM_TOKEN'] : ''; ?></div>
</form>